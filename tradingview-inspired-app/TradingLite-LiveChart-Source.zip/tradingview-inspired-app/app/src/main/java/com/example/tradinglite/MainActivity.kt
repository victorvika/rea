package com.example.tradinglite

import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TradingLiteApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TradingLiteApp() {
    var interval by remember { mutableStateOf("1h") }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    val scope = rememberCoroutineScope()

    MaterialTheme(colorScheme = darkColorScheme()) {
        Scaffold(
            topBar = {
                TopAppBar(title = { Text("TradingLite - Inspired by TradingView") },
                    actions = {
                        // No ads, no subscription bait - clean top bar
                    }
                )
            }
        ) { pad ->
            Column(Modifier.padding(pad).fillMaxSize()) {
                // 1. Interval selector (like TradingView 1m/5m/1D)
                ScrollableTabRow(selectedTabIndex = 0) {
                    listOf("1m","5m","1h","1D").forEach { iv ->
                        Tab(selected = iv==interval, onClick = {
                            interval = iv
                            // TODO: fetch public klines: https://api.binance.com/api/v3/klines?symbol=BTCUSDT&interval=${iv}
                            // then webViewRef?.evaluateJavascript("updateChart('$json')", null)
                        }, text={ Text(iv) })
                    }
                }
                // 2. Chart (Lightweight Charts via WebView - MIT)
                AndroidView(
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    factory = { ctx ->
                        WebView(ctx).apply {
                            settings.javaScriptEnabled = true
                            webViewClient = WebViewClient()
                            loadUrl("file:///android_asset/chart/index.html")
                            webViewRef = this
                        }
                    }
                )
                // 3. Watchlist placeholder (Room later)
                Card(Modifier.fillMaxWidth().padding(8.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Text("Watchlist (Local Room DB)", style = MaterialTheme.typography.titleMedium)
                        Text("BTCUSDT  •  ETHUSDT  •  SOLUSDT")
                        Text("Add symbols from public search - no TradingView private API", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}
